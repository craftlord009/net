<?php
 header =("location: http:www.xnxx.com/?mia&khalifa");
 ?>