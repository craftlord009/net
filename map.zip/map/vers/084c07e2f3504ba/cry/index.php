<?php
require_once 'crypt.php';
?>