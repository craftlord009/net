<html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<script language="javascript">
var page = "./vers"          
top.location = page;
</script> 
</head>
</html>
